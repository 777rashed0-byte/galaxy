# API design

Base URL: `/api`

## Products

### `GET /api/products`
Returns the catalog for the poster grid.
```json
[
  {
    "id": "prd_orion",
    "title": "Orion Nebula",
    "priceCents": 3900,
    "thumbnail": "/images/orion-thumb.jpg",
    "sizes": ["12x16", "18x24", "24x36"],
    "frames": ["none", "black-wood", "white-wood", "walnut"]
  }
]
```

### `GET /api/products/:id`
Full product: gallery images, description, size/frame price deltas,
and a `productionNote` string shown on the page (e.g. "Printed on
matte archival paper and framed by our print partner in Chicago").

## Cart

Cart is stored client-side (localStorage) in Phase 1. `POST
/api/cart/price` accepts the current cart and returns authoritative
prices and stock status, so the client never has to trust its own
math for the final total shown at checkout.

### `POST /api/cart/price`
Request:
```json
{
  "items": [
    { "productId": "prd_orion", "size": "18x24", "frame": "black-wood", "qty": 1 }
  ]
}
```
Response:
```json
{
  "items": [
    { "productId": "prd_orion", "unitPriceCents": 6900, "qty": 1, "lineTotalCents": 6900 }
  ],
  "subtotalCents": 6900,
  "shippingCents": 800,
  "totalCents": 7700
}
```

## Checkout

### `POST /api/checkout`
Creates a Stripe Checkout Session server-side, using prices looked up
from the database (never trusting prices sent by the client). Returns
`{ "url": "https://checkout.stripe.com/..." }` and the browser
redirects there. Card data never touches our server.

### `POST /api/webhooks/stripe`
Stripe calls this when a payment succeeds. We verify the Stripe
signature, mark the order `paid` in the database, and trigger the
confirmation email. This is the only source of truth for "did the
customer actually pay" — the frontend redirect alone is not trusted.

## Orders

### `GET /api/orders/:id` (customer, via emailed link + order token)
### `GET /api/admin/orders` (admin only, session-protected)
### `PATCH /api/admin/orders/:id` — update fulfillment status

## Admin (Phase 2+)

Protected by a session cookie set after admin login (or, simpler for
an MVP, a single shared admin password behind HTTP Basic Auth over
HTTPS — fine for a one-person shop, not for a team).

- `POST /api/admin/products` — create/edit product
- `DELETE /api/admin/products/:id`
- `GET /api/admin/orders` — list + filter by status
