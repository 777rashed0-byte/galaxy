const API_BASE = import.meta.env.VITE_API_BASE ?? "http://localhost:4000/api";

export type ProductSummary = {
  id: string;
  title: string;
  priceCents: number;
  thumbnail: string | null;
  sizes: string[];
  frames: string[];
};

export type ProductDetail = ProductSummary & {
  description: string;
  productionNote: string;
  images: { url: string; alt: string }[];
  sizes: { label: string; priceDeltaCents: number }[];
  frames: { id: string; label: string; priceDeltaCents: number }[];
};

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? `Request failed (${res.status})`);
  }
  return res.json();
}

export const api = {
  getProducts: () => request<ProductSummary[]>("/products"),
  getProduct: (id: string) => request<ProductDetail>(`/products/${id}`),
  priceCart: (items: { productId: string; size: string; frame: string; qty: number }[]) =>
    request("/cart/price", { method: "POST", body: JSON.stringify({ items }) }),
  checkout: (payload: unknown) =>
    request<{ url: string; orderId: string }>("/checkout", {
      method: "POST",
      body: JSON.stringify(payload)
    })
};
