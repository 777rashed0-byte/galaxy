import express from "express";
import cors from "cors";
import "dotenv/config";

import productsRouter from "./routes/products.js";
import cartRouter from "./routes/cart.js";
import checkoutRouter, { stripeWebhookHandler } from "./routes/checkout.js";

const app = express();

// Stripe webhooks need the RAW body to verify the signature, so this
// route is registered BEFORE express.json() and given its own parser.
app.post(
  "/api/webhooks/stripe",
  express.raw({ type: "application/json" }),
  stripeWebhookHandler
);

app.use(cors({ origin: process.env.FRONTEND_URL }));
app.use(express.json());

app.use("/api/products", productsRouter);
app.use("/api/cart", cartRouter);
app.use("/api/checkout", checkoutRouter);

app.get("/api/health", (_req, res) => res.json({ ok: true }));

// Central error handler — never leak stack traces or payment details.
app.use(
  (
    err: Error,
    _req: express.Request,
    res: express.Response,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _next: express.NextFunction
  ) => {
    console.error("[error]", err.message);
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
);

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Galaxy backend running on :${port}`));
