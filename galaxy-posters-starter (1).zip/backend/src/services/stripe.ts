import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  console.warn("STRIPE_SECRET_KEY is not set — checkout will fail until it is.");
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY ?? "", {
  apiVersion: "2024-06-20"
});

export type CheckoutLineItem = {
  title: string;
  description: string; // e.g. "18x24, Black wood frame"
  unitAmountCents: number;
  qty: number;
};

/**
 * Creates a Stripe-hosted Checkout Session. Card details are entered
 * on Stripe's own page and never touch our server — this is what
 * keeps us out of PCI-DSS scope beyond the simplest tier (SAQ A).
 */
export async function createCheckoutSession(params: {
  orderId: string;
  customerEmail: string;
  items: CheckoutLineItem[];
  shippingCents: number;
}) {
  const line_items: Stripe.Checkout.SessionCreateParams.LineItem[] =
    params.items.map((item) => ({
      quantity: item.qty,
      price_data: {
        currency: "usd",
        unit_amount: item.unitAmountCents,
        product_data: {
          name: item.title,
          description: item.description
        }
      }
    }));

  if (params.shippingCents > 0) {
    line_items.push({
      quantity: 1,
      price_data: {
        currency: "usd",
        unit_amount: params.shippingCents,
        product_data: { name: "Shipping" }
      }
    });
  }

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_email: params.customerEmail,
    line_items,
    metadata: { orderId: params.orderId },
    success_url: `${process.env.FRONTEND_URL}/order/confirmation?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.FRONTEND_URL}/cart`
  });

  return session;
}

/** Verifies a webhook came from Stripe using the raw request body. */
export function constructWebhookEvent(rawBody: Buffer, signature: string) {
  return stripe.webhooks.constructEvent(
    rawBody,
    signature,
    process.env.STRIPE_WEBHOOK_SECRET ?? ""
  );
}
