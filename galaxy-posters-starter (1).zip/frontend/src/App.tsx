import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { CartProvider, useCart } from "./cart/CartContext";
import { ProductList } from "./components/ProductList";
import { ProductDetail } from "./components/ProductDetail";
import { Cart } from "./components/Cart";
import { Checkout } from "./components/Checkout";
import { OrderConfirmation } from "./components/OrderConfirmation";

function Nav() {
  const { items } = useCart();
  const count = items.reduce((sum, i) => sum + i.qty, 0);
  return (
    <nav className="site-nav">
      <Link to="/" className="site-nav__logo">Galaxy</Link>
      <Link to="/cart" className="site-nav__cart">
        Cart{count > 0 && <span className="site-nav__cart-count">{count}</span>}
      </Link>
    </nav>
  );
}

export default function App() {
  return (
    <CartProvider>
      <BrowserRouter>
        <a href="#main" className="skip-link">Skip to content</a>
        <header>
          <Nav />
        </header>
        <main id="main">
          <Routes>
            <Route path="/" element={<ProductList />} />
            <Route path="/posters/:id" element={<ProductDetail />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/order/confirmation" element={<OrderConfirmation />} />
          </Routes>
        </main>
        <footer className="site-footer">
          <p>© {new Date().getFullYear()} Galaxy. Posters printed and framed on demand.</p>
        </footer>
      </BrowserRouter>
    </CartProvider>
  );
}
