import { useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { useCart } from "../cart/CartContext";

export function OrderConfirmation() {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get("session_id");
  const { clear } = useCart();

  // The redirect here only means Stripe sent the customer back — the
  // real "is this order paid" fact comes from the webhook on the
  // backend. This page just clears the local cart and confirms the
  // customer landed back safely; it does not mark anything as paid.
  useEffect(() => {
    if (sessionId) clear();
  }, [sessionId, clear]);

  if (!sessionId) {
    return (
      <div>
        <p>We couldn't find your order confirmation.</p>
        <Link to="/">Return to shop</Link>
      </div>
    );
  }

  return (
    <div className="order-confirmation">
      <h1>Thanks for your order!</h1>
      <p>
        A receipt is on its way to your inbox. You can also check your
        order status any time using the link in that email.
      </p>
      <Link to="/" className="btn btn--secondary">Keep browsing</Link>
    </div>
  );
}
