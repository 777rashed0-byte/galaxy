import { Router } from "express";
import { z } from "zod";

const CartItemSchema = z.object({
  productId: z.string(),
  size: z.string(),
  frame: z.string(),
  qty: z.number().int().positive().max(20)
});
const CartRequestSchema = z.object({ items: z.array(CartItemSchema).min(1) });

// In a real build this looks prices up from the `products` /
// `product_sizes` / `frame_options` tables. Never trust a price the
// client sends — that's how people give themselves free posters.
const SHIPPING_FLAT_CENTS = 800;

const router = Router();

router.post("/price", async (req, res) => {
  const parsed = CartRequestSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid cart payload" });
  }

  // TODO: replace with a real DB lookup per item.
  const priced = parsed.data.items.map((item) => {
    const unitPriceCents = 2000; // placeholder — look this up for real (poster $20 + frame $35 if chosen)
    return {
      ...item,
      unitPriceCents,
      lineTotalCents: unitPriceCents * item.qty
    };
  });

  const subtotalCents = priced.reduce((sum, i) => sum + i.lineTotalCents, 0);
  const totalCents = subtotalCents + SHIPPING_FLAT_CENTS;

  res.json({
    items: priced,
    subtotalCents,
    shippingCents: SHIPPING_FLAT_CENTS,
    totalCents
  });
});

export default router;
