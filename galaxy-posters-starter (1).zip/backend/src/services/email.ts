import nodemailer from "nodemailer";

type OrderItem = { title: string; size: string; frame: string; qty: number; lineTotalCents: number };

type ConfirmationEmail = {
  to: string;
  orderId: string;
  items: OrderItem[];
  totalCents: number;
  orderStatusUrl: string; // link using the order's private token
};

const money = (cents: number) => `$${(cents / 100).toFixed(2)}`;

function renderReceiptText(email: ConfirmationEmail) {
  const lines = email.items
    .map((i) => `  ${i.qty} x ${i.title} (${i.size}, ${i.frame}) — ${money(i.lineTotalCents)}`)
    .join("\n");

  return [
    `Thanks for your order, #${email.orderId.slice(0, 8)}.`,
    "",
    lines,
    "",
    `Total: ${money(email.totalCents)}`,
    "",
    `Track your order: ${email.orderStatusUrl}`,
    "",
    "This is an automated receipt from Galaxy. We print and frame",
    "posters on demand through our print partner — nothing here is",
    "hand-painted or one-of-a-kind unless the listing says so."
  ].join("\n");
}

// Nodemailer is configured for plain SMTP here. Swap the transport
// for Resend, Postmark, or SES if you'd rather use an email API —
// the renderReceiptText() function stays the same either way.
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT ?? 587),
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
});

export async function sendOrderConfirmation(email: ConfirmationEmail) {
  await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to: email.to,
    subject: `Your Galaxy order #${email.orderId.slice(0, 8)} is confirmed`,
    text: renderReceiptText(email)
  });
}
