import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, type ProductSummary } from "../api/client";

const money = (cents: number) => `$${(cents / 100).toFixed(2)}`;

export function ProductList() {
  const [products, setProducts] = useState<ProductSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .getProducts()
      .then(setProducts)
      .catch((e) => setError(e.message));
  }, []);

  if (error) return <p role="alert" className="error-text">Couldn't load posters: {error}</p>;
  if (!products) return <p aria-live="polite">Loading posters…</p>;

  return (
    <ul className="product-grid" aria-label="Poster catalog">
      {products.map((p) => (
        <li key={p.id} className="product-card">
          <Link to={`/posters/${p.id}`} className="product-card__link">
            {p.thumbnail && (
              <img
                src={p.thumbnail}
                alt={p.title}
                loading="lazy"
                className="product-card__image"
              />
            )}
            <span className="product-card__title">{p.title}</span>
            <span className="product-card__price">from {money(p.priceCents)}</span>
          </Link>
        </li>
      ))}
    </ul>
  );
}
