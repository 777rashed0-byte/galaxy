# Terms of sale (starter — replace bracketed details, have a lawyer review)

Last updated: [date]

## What you're buying
Galaxy sells posters, printed on [paper stock] and, if you choose a
frame option, framed by our print partner. Posters are produced to
order — they are printed and framed by machine and by our print
partner's staff, not hand-painted or one-of-a-kind, unless a specific
listing says otherwise.

## Pricing and payment
All prices are shown in USD and include the frame you select.
Payment is processed securely by Stripe at checkout. We do not see
or store your card number.

## Shipping
Orders ship within [X] business days. Shipping cost and estimated
delivery time are shown at checkout before you pay.

## Returns and damage
- Damaged in transit: contact [support email] within [14] days of
  delivery with photos, and we'll replace it or refund you.
- Change of mind: [describe your actual return policy here — many
  print-on-demand shops don't accept change-of-mind returns because
  each poster is printed for that order; say so plainly if that's
  the case].

## Order status
After checkout, you'll get an emailed receipt with a link to check
your order status at any time.

## Contact
[Company name, address, email] for any questions about an order.
