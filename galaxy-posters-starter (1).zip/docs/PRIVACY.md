# Privacy notice (starter — replace bracketed details, have a lawyer review)

Last updated: [date]

Galaxy ("we", "us") sells posters through this website. This notice
explains what we collect and why.

## What we collect
- **Order data**: name, email, shipping address, and what you ordered.
  Used to fulfill and ship your order, and to email your receipt.
- **Payment data**: entered directly into Stripe's checkout page. We
  never receive or store your card number — only a payment status
  and a Stripe reference ID.
- **Basic usage data**: standard server logs (IP address, browser
  type, pages visited) kept for a limited time for security and
  debugging.

## What we don't do
- We don't sell your personal data.
- We don't share your data with anyone except the vendors that help
  us run the store (payment processor, email sender, shipping
  carrier), each bound by their own privacy terms.

## Your choices
- You can ask us to see, correct, or delete the personal data we
  hold about you by emailing [privacy@galaxyposters.com].
- Order records are kept for [X years] for accounting and warranty
  purposes even after a deletion request, as required by law.

## Cookies
[Describe any analytics/cookies you actually use — none are added by
default in this starter.]

## Contact
[Company name, address, email] for any privacy questions.
