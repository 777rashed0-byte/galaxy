import { useState, type FormEvent } from "react";
import { useCart } from "../cart/CartContext";
import { api } from "../api/client";

export function Checkout() {
  const { items, subtotalCents } = useCart();
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState({
    name: "",
    line1: "",
    city: "",
    state: "",
    postalCode: "",
    country: "US"
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      // The backend re-prices every item and creates a Stripe
      // Checkout Session. Card details are entered on Stripe's own
      // page — this app never sees or stores a card number.
      const { url } = await api.checkout({
        customerEmail: email,
        shippingAddress: address,
        items: items.map((i) => ({
          productId: i.productId,
          title: i.title,
          size: i.size,
          frame: i.frame,
          unitAmountCents: i.unitAmountCents,
          qty: i.qty
        }))
      });
      window.location.href = url; // hand off to Stripe Checkout
    } catch (err) {
      setError(err instanceof Error ? err.message : "Checkout failed");
      setSubmitting(false);
    }
  };

  if (items.length === 0) return <p>Your cart is empty.</p>;

  return (
    <form onSubmit={handleSubmit} className="checkout-form">
      <h1>Checkout</h1>

      <label>
        Email — we'll send your receipt here
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="email"
        />
      </label>

      <fieldset>
        <legend>Shipping address</legend>
        <label>
          Full name
          <input
            required
            value={address.name}
            onChange={(e) => setAddress({ ...address, name: e.target.value })}
            autoComplete="name"
          />
        </label>
        <label>
          Address
          <input
            required
            value={address.line1}
            onChange={(e) => setAddress({ ...address, line1: e.target.value })}
            autoComplete="address-line1"
          />
        </label>
        <label>
          City
          <input
            required
            value={address.city}
            onChange={(e) => setAddress({ ...address, city: e.target.value })}
            autoComplete="address-level2"
          />
        </label>
        <label>
          State
          <input
            required
            value={address.state}
            onChange={(e) => setAddress({ ...address, state: e.target.value })}
            autoComplete="address-level1"
          />
        </label>
        <label>
          Postal code
          <input
            required
            value={address.postalCode}
            onChange={(e) => setAddress({ ...address, postalCode: e.target.value })}
            autoComplete="postal-code"
          />
        </label>
      </fieldset>

      <p className="checkout-form__total">Subtotal: ${(subtotalCents / 100).toFixed(2)} (+ shipping)</p>

      {error && <p role="alert" className="error-text">{error}</p>}

      <button type="submit" className="btn btn--primary" disabled={submitting}>
        {submitting ? "Redirecting to secure payment…" : "Continue to payment"}
      </button>
      <p className="checkout-form__security-note">
        Payment is handled securely by Stripe. We never see or store your card number.
      </p>
    </form>
  );
}
