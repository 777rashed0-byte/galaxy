-- Galaxy Posters — database schema (PostgreSQL)

CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT,                 -- null until Phase 3 accounts ship
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE products (
  id               TEXT PRIMARY KEY,        -- e.g. 'prd_orion'
  title            TEXT NOT NULL,
  description      TEXT NOT NULL,
  production_note  TEXT NOT NULL,           -- honest "how it's made" line, always shown
  base_price_cents INTEGER NOT NULL,
  active           BOOLEAN NOT NULL DEFAULT true,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE product_images (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id  TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  alt_text    TEXT NOT NULL,               -- required for accessibility
  sort_order  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE product_sizes (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id       TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  label            TEXT NOT NULL,          -- '12x16', '18x24', '24x36'
  price_delta_cents INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE frame_options (
  id                TEXT PRIMARY KEY,      -- 'none', 'black-wood', 'white-wood', 'walnut'
  label             TEXT NOT NULL,
  price_delta_cents INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE orders (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          UUID REFERENCES users(id),
  customer_email   TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'pending', -- pending | paid | fulfilled | cancelled
  stripe_session_id TEXT UNIQUE,
  subtotal_cents   INTEGER NOT NULL,
  shipping_cents   INTEGER NOT NULL,
  total_cents      INTEGER NOT NULL,
  shipping_address JSONB NOT NULL,
  order_token      TEXT NOT NULL UNIQUE,   -- lets the customer view order status without login
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE order_items (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id       UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id     TEXT NOT NULL REFERENCES products(id),
  size_label     TEXT NOT NULL,
  frame_id       TEXT NOT NULL REFERENCES frame_options(id),
  qty            INTEGER NOT NULL,
  unit_price_cents INTEGER NOT NULL
);

-- Never store raw card numbers, CVV, or full Stripe payment payloads here.
-- Stripe holds all payment-method data; we only keep the session id and status.

CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_order_items_order_id ON order_items(order_id);
