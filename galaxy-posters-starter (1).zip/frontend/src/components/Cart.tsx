import { Link } from "react-router-dom";
import { useCart } from "../cart/CartContext";

const money = (cents: number) => `$${(cents / 100).toFixed(2)}`;

export function Cart() {
  const { items, removeItem, updateQty, subtotalCents } = useCart();

  if (items.length === 0) {
    return (
      <div className="cart cart--empty">
        <p>Your cart is empty.</p>
        <Link to="/" className="btn btn--secondary">Browse posters</Link>
      </div>
    );
  }

  return (
    <div className="cart">
      <ul className="cart__items">
        {items.map((item, index) => (
          <li key={`${item.productId}-${item.size}-${item.frame}-${index}`} className="cart__item">
            {item.thumbnail && <img src={item.thumbnail} alt="" className="cart__item-image" />}
            <div className="cart__item-details">
              <p className="cart__item-title">{item.title}</p>
              <p className="cart__item-options">{item.size} · {item.frame}</p>
              <label>
                Qty
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={item.qty}
                  onChange={(e) => updateQty(index, Math.max(1, Number(e.target.value)))}
                />
              </label>
            </div>
            <p className="cart__item-price">{money(item.unitAmountCents * item.qty)}</p>
            <button type="button" className="btn btn--text" onClick={() => removeItem(index)}>
              Remove
            </button>
          </li>
        ))}
      </ul>

      <div className="cart__summary">
        <p>Subtotal: {money(subtotalCents)}</p>
        <p className="cart__shipping-note">Shipping and tax are calculated at checkout.</p>
        <Link to="/checkout" className="btn btn--primary">Go to checkout</Link>
      </div>
    </div>
  );
}
