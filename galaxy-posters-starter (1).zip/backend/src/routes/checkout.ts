import { Router, type Request, type Response } from "express";
import crypto from "node:crypto";
import { z } from "zod";
import { createCheckoutSession, constructWebhookEvent } from "../services/stripe.js";
import { sendOrderConfirmation } from "../services/email.js";

const CheckoutSchema = z.object({
  customerEmail: z.string().email(),
  items: z
    .array(
      z.object({
        productId: z.string(),
        title: z.string(),
        size: z.string(),
        frame: z.string(),
        unitAmountCents: z.number().int().positive(),
        qty: z.number().int().positive().max(20)
      })
    )
    .min(1),
  shippingAddress: z.object({
    name: z.string(),
    line1: z.string(),
    city: z.string(),
    state: z.string(),
    postalCode: z.string(),
    country: z.string()
  })
});

const SHIPPING_FLAT_CENTS = 800;
const router = Router();

router.post("/", async (req: Request, res: Response) => {
  const parsed = CheckoutSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid checkout payload" });
  }
  const { customerEmail, items, shippingAddress } = parsed.data;

  // TODO (Phase 2): re-price every item against the database here,
  // the same way /api/cart/price does, and reject if amounts differ
  // from what the client displayed. Never trust client-sent prices.

  const orderId = crypto.randomUUID();
  const orderToken = crypto.randomBytes(16).toString("hex");

  // TODO: INSERT the order + order_items rows here, status = 'pending',
  // before creating the Stripe session, so we have something to mark
  // 'paid' when the webhook arrives.

  const session = await createCheckoutSession({
    orderId,
    customerEmail,
    shippingCents: SHIPPING_FLAT_CENTS,
    items: items.map((i) => ({
      title: i.title,
      description: `${i.size}, ${i.frame}`,
      unitAmountCents: i.unitAmountCents,
      qty: i.qty
    }))
  });

  res.json({ url: session.url, orderId, orderToken });
});

export default router;

/**
 * Stripe webhook handler — mounted separately in server.ts with the
 * raw body parser, since signature verification needs the exact
 * bytes Stripe sent.
 */
export async function stripeWebhookHandler(req: Request, res: Response) {
  const signature = req.headers["stripe-signature"];
  if (typeof signature !== "string") {
    return res.status(400).send("Missing signature");
  }

  let event;
  try {
    event = constructWebhookEvent(req.body as Buffer, signature);
  } catch (err) {
    console.error("[stripe webhook] signature verification failed");
    return res.status(400).send("Invalid signature");
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as { metadata?: { orderId?: string }; customer_email?: string | null };
    const orderId = session.metadata?.orderId;

    // TODO: UPDATE orders SET status = 'paid' WHERE id = orderId
    // Then load the real order + items from the DB before emailing.

    if (orderId && session.customer_email) {
      await sendOrderConfirmation({
        to: session.customer_email,
        orderId,
        items: [], // fill in from the DB in the real implementation
        totalCents: 0,
        orderStatusUrl: `${process.env.FRONTEND_URL}/order/${orderId}`
      });
    }
  }

  res.json({ received: true });
}
