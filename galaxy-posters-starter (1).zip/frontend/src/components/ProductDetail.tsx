import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api, type ProductDetail as ProductDetailType } from "../api/client";
import { useCart } from "../cart/CartContext";

const money = (cents: number) => `$${(cents / 100).toFixed(2)}`;

export function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addItem } = useCart();

  const [product, setProduct] = useState<ProductDetailType | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeImage, setActiveImage] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [size, setSize] = useState<string | null>(null);
  const [frame, setFrame] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    api
      .getProduct(id)
      .then((p) => {
        setProduct(p);
        setSize(p.sizes[0]?.label ?? null);
        setFrame(p.frames[0]?.id ?? null);
      })
      .catch((e) => setError(e.message));
  }, [id]);

  if (error) return <p role="alert" className="error-text">Couldn't load this poster: {error}</p>;
  if (!product) return <p aria-live="polite">Loading…</p>;

  const sizeDelta = product.sizes.find((s) => s.label === size)?.priceDeltaCents ?? 0;
  const frameDelta = product.frames.find((f) => f.id === frame)?.priceDeltaCents ?? 0;
  const unitAmountCents = product.priceCents + sizeDelta + frameDelta;

  const handleAddToCart = () => {
    if (!size || !frame) return;
    addItem({
      productId: product.id,
      title: product.title,
      size,
      frame: product.frames.find((f) => f.id === frame)?.label ?? frame,
      unitAmountCents,
      qty: 1,
      thumbnail: product.images[0]?.url ?? null
    });
    navigate("/cart");
  };

  return (
    <article className="product-detail">
      <section aria-label="Product images" className="product-detail__gallery">
        <button
          type="button"
          className="product-detail__main-image-button"
          onClick={() => setLightboxOpen(true)}
        >
          <img
            src={product.images[activeImage]?.url}
            alt={product.images[activeImage]?.alt ?? product.title}
            className="product-detail__main-image"
          />
          <span className="product-detail__zoom-hint">Click to zoom</span>
        </button>

        {product.images.length > 1 && (
          <div className="product-detail__thumbnails" role="tablist" aria-label="Product photos">
            {product.images.map((img, i) => (
              <button
                key={img.url}
                role="tab"
                aria-selected={i === activeImage}
                className="product-detail__thumbnail"
                onClick={() => setActiveImage(i)}
              >
                <img src={img.url} alt="" />
              </button>
            ))}
          </div>
        )}

        {lightboxOpen && (
          <div
            className="lightbox"
            role="dialog"
            aria-modal="true"
            aria-label={`${product.title}, full size`}
            onClick={() => setLightboxOpen(false)}
          >
            <img src={product.images[activeImage]?.url} alt={product.images[activeImage]?.alt ?? product.title} />
            <button
              type="button"
              className="lightbox__close"
              onClick={() => setLightboxOpen(false)}
              aria-label="Close full-size image"
            >
              ×
            </button>
          </div>
        )}
      </section>

      <section className="product-detail__info">
        <h1>{product.title}</h1>
        <p className="product-detail__description">{product.description}</p>
        <p className="product-detail__production-note">{product.productionNote}</p>

        <fieldset>
          <legend>Size</legend>
          {product.sizes.map((s) => (
            <label key={s.label} className="option-pill">
              <input
                type="radio"
                name="size"
                value={s.label}
                checked={size === s.label}
                onChange={() => setSize(s.label)}
              />
              {s.label}
              {s.priceDeltaCents > 0 && ` (+${money(s.priceDeltaCents)})`}
            </label>
          ))}
        </fieldset>

        <fieldset>
          <legend>Frame</legend>
          {product.frames.map((f) => (
            <label key={f.id} className="option-pill">
              <input
                type="radio"
                name="frame"
                value={f.id}
                checked={frame === f.id}
                onChange={() => setFrame(f.id)}
              />
              {f.label}
              {f.priceDeltaCents > 0 && ` (+${money(f.priceDeltaCents)})`}
            </label>
          ))}
        </fieldset>

        <p className="product-detail__price" aria-live="polite">
          {money(unitAmountCents)}
        </p>

        <button type="button" className="btn btn--primary" onClick={handleAddToCart}>
          Add to cart
        </button>
      </section>
    </article>
  );
}
