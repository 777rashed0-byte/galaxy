import { Router } from "express";

// Phase 1: seeded in-memory data so the frontend has something real
// to render. Swap this for real SQL queries against `products`,
// `product_images`, and `product_sizes` once Postgres is wired up.

const PRODUCTS = [
  {
    id: "prd_orion",
    title: "Orion Nebula",
    description:
      "A wide-field shot of the Orion Nebula, printed on matte archival paper.",
    productionNote:
      "Printed and framed by our print partner in Chicago, on demand — not mass-produced or hand-painted.",
    basePriceCents: 2000,
    images: [
      { url: "/images/orion-1.jpg", alt: "Orion Nebula poster, straight-on view" },
      { url: "/images/orion-2.jpg", alt: "Orion Nebula poster in a black wood frame, angled" }
    ],
    sizes: [
      { label: "12x16", priceDeltaCents: 0 },
      { label: "18x24", priceDeltaCents: 0 },
      { label: "24x36", priceDeltaCents: 0 }
    ],
    frames: [
      { id: "none", label: "No frame", priceDeltaCents: 0 },
      { id: "black-wood", label: "Black wood", priceDeltaCents: 3500 },
      { id: "white-wood", label: "White wood", priceDeltaCents: 3500 },
      { id: "walnut", label: "Walnut", priceDeltaCents: 3500 }
    ]
  },
  {
    id: "prd_andromeda",
    title: "Andromeda Galaxy",
    description: "Our nearest galactic neighbor, in deep blues and violet.",
    productionNote:
      "Printed and framed by our print partner in Chicago, on demand — not mass-produced or hand-painted.",
    basePriceCents: 2000,
    images: [
      { url: "/images/andromeda-1.jpg", alt: "Andromeda Galaxy poster, straight-on view" }
    ],
    sizes: [
      { label: "12x16", priceDeltaCents: 0 },
      { label: "18x24", priceDeltaCents: 0 },
      { label: "24x36", priceDeltaCents: 0 }
    ],
    frames: [
      { id: "none", label: "No frame", priceDeltaCents: 0 },
      { id: "black-wood", label: "Black wood", priceDeltaCents: 3500 },
      { id: "white-wood", label: "White wood", priceDeltaCents: 3500 },
      { id: "walnut", label: "Walnut", priceDeltaCents: 3500 }
    ]
  }
];

const router = Router();

router.get("/", (_req, res) => {
  res.json(
    PRODUCTS.map(({ id, title, basePriceCents, images, sizes, frames }) => ({
      id,
      title,
      priceCents: basePriceCents,
      thumbnail: images[0]?.url ?? null,
      sizes: sizes.map((s) => s.label),
      frames: frames.map((f) => f.id)
    }))
  );
});

router.get("/:id", (req, res) => {
  const product = PRODUCTS.find((p) => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: "Product not found" });
  res.json(product);
});

export default router;
